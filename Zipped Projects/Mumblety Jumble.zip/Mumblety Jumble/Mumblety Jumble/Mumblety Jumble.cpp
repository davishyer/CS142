#include<iostream>
#include<vector>
#include<fstream>
#include<string>
#include<cctype>
#include<time.h>

using namespace std;

//Reading the words into the vector
void add(char read, ifstream& text, vector<char>& jumbled)
{	
	
	char ch;
	vector<char> to_jumble;
	while(text.get(ch))
	{
		//Process characters into a vector
		if(isalnum)
		{
			to_jumble.push_back(ch);

			//Jumble characters only in middle
			for(int i = 1; i < to_jumble.size() - 1; i++)
			{
				int j = rand() % to_jumble.size();
				if(j = to_jumble.size() - 1)
				{
					to_jumble[j] = to_jumble[j];
				}

				else if(j = 0)
				{
					to_jumble[j] = to_jumble[j];
				}

				else
				{
					char temp = to_jumble[i];
					to_jumble[j] = to_jumble[i];
					to_jumble[i] = temp;
				}

			}
		}

		//Starting a new word
		else
		{
			for(int i = 0; i < to_jumble.size(); i++)
			{
				jumbled.push_back(to_jumble[i]);
			}
			jumbled.push_back(ch);
			to_jumble.clear();
		}
	}
	return;
}

void write(vector<char>& jumbled, ofstream& newfile)
{
	for(int i = 0; i < jumbled.size(); i ++)
	{
		newfile << jumbled[i];
	}
}

int main()
{
	vector<char> jumbled;
	//Prompting user for filename
	cout << "Please enter the name of the file and extension you wish to jumble: ";
	string jumbling;
	cin >> jumbling;
	ifstream text;
	text.open(jumbling.c_str());

	//Checking if file opens
	while(text.fail())
	{
		cout << endl;
		cout << "Invalid Entry" << endl;
		cout << "Please enter the name of the file and extension you wish to jumble: ";
		cin >> jumbling;
	}
	char read;
	char ch;

	//Reading the file 
	while(!text.eof())
	{	
		text.get(ch) >> read;
		add(read, text, jumbled);
	}

	//Saving vector to new file
	cout << "Please enter the name of the file and extension you wish to save the jumbled memo to: ";
	string jumble;
	cin >> jumble;
	while(jumble == jumbling)
	{
		cout << "You must choose a new file name." << endl;
		cout << "Please enter the name of the file and extension you wish to save the jumbled memo to: ";
		cin >> jumble;
	}
	ofstream newfile;
	newfile.open(jumble.c_str());
	


	//Closing the file
	text.close();

	system("pause");
	return 0;
}