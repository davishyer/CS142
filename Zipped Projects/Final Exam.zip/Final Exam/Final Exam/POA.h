/*
-------------------------------
Davis Hyer
841110686
"CS 142 Winter 2013 Final Exam
-------------------------------
*/


#pragma once
#include "POAInterface.h"
#include "Lot.h"
#include "Adjacent.h"
#include "Outside.h"
#include "Inside.h"
#include <sstream>
#include <vector>
class POA :
	public POAInterface
{
public:
	POA(void);
	~POA(void);
		/*
		 *	addLot(string)
		 *
		 *	Adds a new Lot to the collection of Lots in the POA. 
		 *  Do not allow Lots with duplicate LIDs (Lot Identification Numbers).
		 *  Do not allow Lots with duplicate surnames, unless the lot is being purchased as 
		 *	an adjacent lot for someone who already owns one main lot, but does not already own an adjacent lot.
		 *
		 *	Reject any string that does not adhere to the following format:
		 *	(Surname) - The name of the Owner of the Lot (single word names only)
		 *  (LID) - An integer containing the unique Lot Identification Number
		 *  (Type) - Can be I, O, or A, meaning Inside, Outside, or Adjacent, respectively
		 *  (Home or Vacant) - Whether the lot has a home on it to begin with or not (case sensitive)
		 *	In Total - (Surname) (LID) (Type) (Home or Vacant)
		 *  Example: Johnson 111 O Home
		 *  Example: Louis 1234 I Vacant
		 *	Example: Jimersoninafitzpatrickbarrelheart 3 A Vacant
		 *
		 *	Return true if a new lot was added; false otherwise.
		 */
		bool addLot(string info);//DONE
		
		/*
		 *	getLot(int)
		 *
		 *	Returns the memory address of a lot whose LID is equal to the given 
		 *	int.  Returns NULL if no lot is found with the given LID.
		 *
		 *	Return a memory address if a lot is found; NULL otherwise.
		 */
		LotInterface* getLot(int LID);//DONE
		
		/*
		 *	getSize()
		 *
		 *	Returns the number of lots in the POA.
		 *
		 *	Return a non-negative integer.
		 */
		int getSize();//DONE
		
		/*
		 *	getPOAbySurname()
		 *
		 *	Returns a vector of LotInterface* sorted by the owners' surnames.
		 *		-If there is an owner with more than 1 lot (aka, one surname on many lots),
		 *		 then you may put his lots in the vector in any order, keeping his surname sorted
		 *		 compared to the other surnames.
		 *
		 *	Return a sorted vector.
		 */
		vector<LotInterface*> getPOAbySurname();//DONE
		
		/*
		 *	getPOAbyLID()
		 *
		 *	Returns a vector of LotInterface* sorted by the LID.
		 *
		 *	Return a sorted vector.
		 */
		vector<LotInterface*> getPOAbyLID();//DONE
		
		/*
		 *	addHome(int)
		 *
		 *	Adds a home to an existing lot if there was not
		 *	already a home on that lot.  The home is added to
		 *	the lot identified by the LID paramater passed in.
		 *
		 *	Return true if a home was added, false if the lot doesn't exist or a home already exists there.
		 */
		bool addHome(int LID);//DONE
		
		/*
		 *	endMonth()
		 *
		 *	"Charges" each lot its standard monthly fees and ends the month for each lot.
		 *
		 *	Returns the total collected by the POA from every lot combined.
		 */
		int endMonth();//DONE

private:
	vector <LotInterface*> Properties;
};

