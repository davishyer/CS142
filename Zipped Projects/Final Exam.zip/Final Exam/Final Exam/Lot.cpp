/*
-------------------------------
Davis Hyer
841110686
"CS 142 Winter 2013 Final Exam
-------------------------------
*/


#include "Lot.h"


Lot::Lot(string surname, int LiD, string building)
{
	Surname = surname;
	LID = LiD;
	Building = building;
}

Lot::~Lot(void)
{
}

int Lot::getLID()
{
	return LID;
}

string Lot::getSurname()
{
	return Surname;
}

int Lot::getMonthlyTotal()
{
	int Total = MonthlyTotal + ExtraCharges + ServiceCharges;
	return Total;
}

bool Lot::hasHome()
{
	if(Building == "House")
	{
		return true;
	}

		return false;
}


void Lot::endOfMonth()
{
	TotalWeeks = 0;
	ServiceCharges = 0;
}

string Lot::toString()
{
	string check = "no";
	string end = "\n"
	if(Building == "House")
	{
		check = "yes";
	}
	cout << "LID: " << getLID() << ", Surname: " << getSurname() << ", Home: " << check << ", Monthly Fees : $" << getMonthlyTotal();
	return end;
}