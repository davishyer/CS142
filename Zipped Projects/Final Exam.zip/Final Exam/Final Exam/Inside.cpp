/*
-------------------------------
Davis Hyer
841110686
"CS 142 Winter 2013 Final Exam
-------------------------------
*/


#include "Inside.h"


Inside::Inside(string surname, int LiD, string building) : Lot(surname, LiD, building)
{
	MonthlyTotal = 100;
	ServiceCharges = 0;
	if(Building == "House")
	{
		ExtraCharges = 70;
	}
	else
	{
		ExtraCharges = 20;
	}
}


Inside::~Inside(void)
{
}

bool Lot::weeklyFees(int numberOfWeeks)
{
	return false;
}

bool Lot::addHome()
{
	if(Building == "House")
	{
		return false;
	}
	Building = "House";
	ExtraCharges = 70;
	return true;
}