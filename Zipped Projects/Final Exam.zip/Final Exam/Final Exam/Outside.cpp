/*
-------------------------------
Davis Hyer
841110686
"CS 142 Winter 2013 Final Exam
-------------------------------
*/


#include "Outside.h"


Outside::Outside(string surname, int LiD, string building) : Lot(surname, LiD, building)
{
	MonthlyTotal = 100;
	if(Building == "House")
	{
		ExtraCharges = 30;
	}
	else
	{
		ExtraCharges = 0;
	}
}


Outside::~Outside(void)
{
}

bool Lot::weeklyFees(int numberOfWeeks)
{
	if(Building == "Vacant")
	{
		ServiceCharges = 50;
		return true;
	}

	TotalWeeks +=numberOfWeeks;
	if(TotalWeeks > 4)
	{
		TotalWeeks-=numberOfWeeks;
		return false;
	}

	ServiceCharges = (10 * TotalWeeks);
	return true;
}

bool Lot::addHome()
{
	if(Building == "House")
	{
		return false;
	}
	Building = "House";
	ExtraCharges = 30;
	return true;
}