/*
-------------------------------
Davis Hyer
841110686
"CS 142 Winter 2013 Final Exam
-------------------------------
*/


#include "Adjacent.h"


Adjacent::Adjacent(string surname, int LiD, string building) : Lot(surname, LiD, building)
{
	MonthlyTotal = 75;
}


Adjacent::~Adjacent(void)
{
}

bool Lot::weeklyFees(int numberOfWeeks)
{
	TotalWeeks +=numberOfWeeks;
	if(TotalWeeks > 4)
	{
		TotalWeeks-=numberOfWeeks;
		return false;
	}

	ServiceCharges = (10 * TotalWeeks);
	return true;
}

bool Lot::addHome()
{
	return false;
}