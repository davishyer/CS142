/*
-------------------------------
Davis Hyer
841110686
"CS 142 Winter 2013 Final Exam
-------------------------------
*/


#pragma once
#include "Lot.h"
class Outside :
	public Lot
{
public:
	Outside(string surname, int LiD, string building);
	virtual ~Outside(void);
	bool weeklyFees(int numberOfWeeks);
	bool addHome();
};

