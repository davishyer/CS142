/*
-------------------------------
Davis Hyer
841110686
"CS 142 Winter 2013 Final Exam
-------------------------------
*/


#pragma once
#include "LotInterface.h"
class Lot :
	public LotInterface
{
protected:
	string Surname;
	int LID;
	string Building;
	int MonthlyTotal;
	int ExtraCharges;
	int TotalWeeks;
	int ServiceCharges;

public:
	Lot(string surname, int LiD, string building);
	Lot(void);
	~Lot(void);
	/*
		 *	getLID()
		 *
		 *	Returns the LID of this lot.
		 */
		int getLID();//DONE

		/*
		 *	getSurname()
		 *
		 *	Returns the surname of the owner of this lot.
		 */
		string getSurname();//DONE

		/*
		 *	getMonthlyTotal()
		 *
		 *	Returns the total cost for this lot for the month including all fees.
		 */
		int getMonthlyTotal();//DONE

		/*
		 *	hasHome()
		 *
		 *	Returns true if the lot has a home, false otherwise.
		 */
		bool hasHome();	//DONE	
		
		/*
		 *	addHome()
		 *	
		 *	Attempts to add a home to the lot; returns true if the home is added, false otherwise.
		 */
		virtual bool addHome() = 0;//DONE

		/*
		 *	weeklyFees(int)
		 *
		 *	Increases this lot's total cost based on the type of lot and the number of weeks.
		 *	Inside lots do not have any weekly fees.
		 *	
		 *	A lawn mowing fee of $10 is imposed for each week that the owner 
		 *	of an outside lot with a home or the owner of an adjacent lot fails to mow his lawn.  
		 *  This can be charged up to four times per month.
		 *
		 *	A weed treatment fee of $50 is imposed on occasion on an outside lot
		 *	without a home.  This fee can only be charged once per month.  
		 *	
		 *	This function may be called on a single lot zero or more times in a month,
		 *	but should do nothing if the number of weeks allowed for that lot type
		 *	for the month would be exceeded.
		 *	
		 *	Returns true if the weekly fees were added, false if the fees could not be added.
		 *	Reject all non-positive input.
		 *	
		 *	Example: An outside lot with a home may be fined 3 weeks (returns true), 
		 *	then 2 weeks (returns false), then 1 week (returns true), 
		 *	then 2 weeks (returns false), then the endOfMonth() method is called,
		 *	then fined 2 weeks (returns true).
		 *	
		 */
		virtual bool weeklyFees(int numberOfWeeks) = 0;//DONE

		/*
		 *	endOfMonth()
		 *
		 *	Restores a lot's current fees to the standard monthly fees for that lot type before weekly fees.
		 *
		 */
		void endOfMonth();//DONE

		/*
		 *	toString()
		 *
		 *	This string must be in the exact format as found below. After 'Home' must be a yes or a no.
		 *	There must be a $ before the price for the Monthly Fees is listed.
		 *
		 *	Returns the information about a lot in a string with the following format:
		 *	LID: x, Surname: name, Home: yes, Monthly Fees: $456.
		 *
		 *
		 */
		string toString();//DONE
};

