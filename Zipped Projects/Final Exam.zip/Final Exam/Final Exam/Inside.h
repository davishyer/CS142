/*
-------------------------------
Davis Hyer
841110686
"CS 142 Winter 2013 Final Exam
-------------------------------
*/


#pragma once
#include "Lot.h"
class Inside :
	public Lot
{
public:
	Inside(string surname, int LiD, string building);
	virtual ~Inside(void);
	bool weeklyFees(int numberOfWeeks);
	bool addHome();
};

