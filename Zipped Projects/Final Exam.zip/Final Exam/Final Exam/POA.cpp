/*
-------------------------------
Davis Hyer
841110686
"CS 142 Winter 2013 Final Exam
-------------------------------
*/


#include "POA.h"


POA::POA(void)
{
}


POA::~POA(void)
{
}

bool POA::addLot(string info)
{
	stringstream ss(info);
	string surname;
	int LiD;
	string type;
	string building;

	if(ss >> surname >> LiD >> type >> building)
	{
		if(type != "I" && type != "O" && type != "A")
		{
			return false;
		}

		if(!ss.eof())
		{
			return false;
		}

		if(building != "House" && building != "Vacant")
		{
			return false;
		}

		for(int i = 0; i < Properties.size(); i++)
		{
			if(LiD == Properties[i]->getLID())
			{
				return false;
			}
		}

		if(type == "I")
		{
			LotInterface* i = new Inside(surname, LiD, building);
			Properties.push_back(i);
			return true;
		}

		if(type == "O")
		{
			LotInterface* o = new Outside(surname, LiD, building);
			Properties.push_back(o);
			return true;
		}

		if(type == "A")
		{
			LotInterface* a = new Adjacent(surname, LiD, building);
			Properties.push_back(a);
			return true;
		}
	}
}

LotInterface* POA::getLot(int LID)
{
	for(int i = 0; i < Properties.size(); i++)
	{
			if(LID == Properties[i]->getLID())
			{
				return Properties[i];
			}
	}
		return NULL;
}

int POA::getSize()
{
	int size = Properties.size();
	return size;
}

vector<LotInterface*> POA::getPOAbySurname()
{
	for(int j = 0; j < Properties.size() - 1; j++)
	{
		for(int i = j; i < Properties.size(); i ++)
		{
			if(Properties[j]->getSurname() < Properties[i]->getSurname())
			{
				
			}
			else if(Properties[j]->getSurname() == Properties[i]->getSurname())
			{

			}
			else
			{
				LotInterface* temp = Properties[j];
				Properties[j] = Properties[i];
				Properties[i] = temp;
			}
		}
	}

	return Properties;
}

vector<LotInterface*> POA::getPOAbyLID()
{
	for(int j = 0; j < Properties.size() - 1; j++)
	{
		for(int i = j; i < Properties.size(); i ++)
		{
			if(Properties[j]->getLID() < Properties[i]->getLID())
			{
				
			}
			else
			{
				LotInterface* temp = Properties[j];
				Properties[j] = Properties[i];
				Properties[i] = temp;
			}
		}
	}

	return Properties;
}

bool POA::addHome(int LID)
{
	for(int i = 0; i < Properties.size(); i++)
	{
		if(LID == Properties[i]->getLID())
		{
			if(Properties[i]->hasHome())
			{
				return false;
			}
			if(Properties[i] == a)
			{
				return false;
			}
			Building = "House";
			return true;
		}
	}

	return false;
}

int POA::endMonth()
{
	int Charges = 0;
	for(int i = 0; i < Properties.size(); i++)
	{
		Charges += Properties[i]->getMonthlyTotal();
		Properties[i]->endOfMonth();
	}

	return Charges;
}