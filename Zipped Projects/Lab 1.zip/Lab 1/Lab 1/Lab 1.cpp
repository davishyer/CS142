#include <iostream>
using namespace std;

int main()
{
    cout << "\t \t \t \t Basic BYU Trivia" << endl;
	cout << "\t \t Questions \t \t \t \t \t Answers" << endl;
	cout << "\n" ;
	cout << "What was the original name of BYU? \t \t \t Brigham Young Academy" << endl;
	cout << "When was BYA established? \t \t \t \t 1875" << endl;
	cout << "Who was the first \"permanent\" principal of BYA? \t Karl Maeser" << endl;
	cout << "When did BYA become BYU? \t \t \t \t 1903" << endl;
	cout << "To what sports conference do we belong? \t \t West Coast Conference" << endl;
	cout << "When did BYU win the national football title? \t \t 1984" << endl;
	cout << "Who won the Heisman Trophy in 1990? \t \t \t Ty Detmer" << endl;
	cin.get();
	return 0;
}