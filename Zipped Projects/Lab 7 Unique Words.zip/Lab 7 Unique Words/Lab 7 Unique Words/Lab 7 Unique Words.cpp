#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;


//Check if word is already added to vector
int check(string filename, string line, ifstream& words, vector<string>& stored)
{
	for(int i = 0; i < stored.size(); i++)
		{
			if(stored[i] == line)
			{
				return i;
			}
		}
	return -1;	
}


//Adding to the vector
void add(string filename, string line, ifstream& words, vector<string>& stored)
{
	int outcome = check(filename, line, words, stored);
	if(outcome != -1)
	{
		return;	
	}
	else
	{
		stored.push_back(line);
	}
}


//Values of entries for alphabetizing
void alpha(vector<string>& stored)
{
	for(int j = 0; j < stored.size() - 1; j++)
	{
		for(int i = j; i < stored.size(); i ++)
		{
			if(stored[j] < stored[i])
			{
				
			}
			else
			{
				string temp = stored[j];
				stored[j] = stored[i];
				stored[i] = temp;
			}
		}
	}
}


int main()
{
	cout << "Please enter the file name and extension: " ;
	vector<string> stored;
	ifstream words;
	string filename;
	cin >> filename;
	words.open(filename.c_str());
	string line;
	//Checking if file fails to open
	while(words.fail())
	{
		cout << endl;
		cout << "Invalid Entry" << endl;
		cout << endl;
		cout << "Please enter the file name and extension: " ;
		cin >> filename;
		words.open(filename.c_str());
	}

	//Reading file line by line and storing to vector
	string skip;
	words >> skip;
	while(!words.eof())
	{
		words >> line;
		add(filename, line, words, stored);
	}

	alpha(stored);

	//Save vector to a new file
	cout << "Please enter the name of the file you would like to create: ";
	string newname;
	cin >> newname;
	ofstream newwords;
	newwords.open(newname.c_str());
	newwords << stored.size() << endl;
	for(int i = 0; i < stored.size(); i++)
	{
		newwords << stored[i];
		if(i != stored.size())
		{
			newwords << endl;
		}
	}

	


	//Close after reading into vector
	words.close();

	system("pause");
	return 0;
}