#include "Car.h"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

//Prompts user for input to select option
int choice(int& option, int random)
{
	cout << "Please enter the option number that you wish: " << endl;
	cout << "\t 1. Show current inventory" << endl;
	cout << "\t 2. Show current balance" << endl;
	cout << "\t 3. Buy a car" << endl;
	cout << "\t 4. Sell a car" << endl;
	cout << "\t 5. Paint a car" << endl;
	cout << "\t 6. Load File" << endl;
	cout << "\t 7. Save File" << endl;
	cout << "\t 8. Quit Program" << endl;
	cin >> option;
	return option;
}

int main()
{
	vector<Car> cars;
	string name;
	string color;
	string new_color;
	double value = 0;
	Car c(name, color, value);
	int option = 0;
	int random = 0;
	double balance = 10000.00;
	choice(option, random);
	while(option != 8)
	{
//Displays current inventory
		if(option == 1)
		{
			if(cars.empty())
			{
				cout << "There are no cars in the inventory \n" << endl;
				choice(option, random);
			}
			
			else
			{
				for(int i = 0; i < cars.size(); i++)
				{
					cout << cars[i].toString() << endl;
				}
				cout << endl;
				choice(option, random);
			}
		}

//Displays current balance
		else if(option == 2)
		{
			cout << "Current balance is : $" << balance << " \n " << endl;
			choice(option, random);
		}

//Buying a car
		else if(option == 3)
		{
			bool found = false;
			cout << "Enter the name of the car: ";
			cin >> name;
			for(int i = 0; i < cars.size(); i ++)
			{
				if(name == cars[i].getName())
				{
					cout << "\n\nThere is already a car of that name in the inventory\n\n" << endl;
					found = true;
				}
			}
			
			if(found == false)
			{
				cout << "Enter the color of the car: ";
				cin >> color;

				cout << "Enter the price of the car: ";
				cin >> value;
				if(value > balance)
				{
					cout << "Insufficent balance to purchase car" << endl;
				}

				else
				{
					Car newCar(name, color, value);
					cars.push_back(newCar);
					balance = balance - value;
					cout << "\n\n" << name << " was added to the inventory\n\n" << endl;
				}
				
			}
			choice(option, random);
		}

//Selling a car
		else if(option == 4)
		{
			int location;
			bool found = false;
			cout << "Enter the name of the car you wish to sell: ";
			cin >> name;
			for(int i = 0; i < cars.size(); i++)
			{
				if(name == cars[i].getName())
				{
					found = true;
					location = i;
				}
			}

			if(found == false)
			{
				cout << "\n\nCould not find " << name << " in the inventory\n\n";
			}

			else if(found == true)
			{
				double sell = cars[location].getPrice();
				balance = balance + sell;
				cars.pop_back();
				cout << "\n\n" << name << " was sold\n\n\n";
			}
		choice(option, random);
		}

//Painting a car
		else if(option == 5)
		{
			int location;
			bool found = false;
			cout << "\n\nEnter the name of the car you wish to paint: ";
			cin >> name;
			for(int i = 0; i < cars.size(); i++)
			{
				if( name == cars[i].getName())
				{
					found = true;
					location = i;
				}
			}
			
			if(found == false)
			{
				cout << "\n\nCould not find " << name << " in the inventory\n\n" << endl;
			}
			
			
			else if(found == true)
			{
				cout << "\n\nEnter the color you wish to paint the car: ";
				cin >> new_color;
				cars[location].paint(new_color);
				cout << "\n\n" << name << " was painted " << new_color << "\n\n" << endl;
			}

			choice(option, random);
		}

//Loading a file
		else if(option == 6)
		{
			ifstream in_file;
			cout << "\n\nEnter the name of the file: ";
			string filename;
			cin >> filename;
			in_file.open(filename.c_str());
			while(in_file.fail())
			{
				cout << "\n\nThe file was not opened\n\n";
				cout << "Enter the name of the file: ";
				cin >> filename;
				in_file.open(filename.c_str());
			}

			double added;
			in_file >> added;
			balance = balance + added;
			while(in_file >> name >> color >> value)
			{
				Car file(name, color, value);
				cars.push_back(file);
			}

			choice(option, random);
		}

//Saving a file
		else if(option == 7)
		{
			cout << "Enter the name of the file to save to: ";
			string filename;
			cin >> filename;
			ofstream out_file;
			out_file.open(filename.c_str());
			out_file << balance << endl;
			for(int i = 0; i < cars.size(); i++)
			{
				out_file << cars[i].getName() << " " << cars[i].getColor() << " " << cars[i].getPrice() << endl;
			}
			choice(option, random);
		}

//Checking for improper input
		else
		{
			cout << "Invalid Entry \n" << endl;
			choice(option, random);
		}
	}

	cout << "Good Bye" << endl;


	system("pause");
	return 0;
}