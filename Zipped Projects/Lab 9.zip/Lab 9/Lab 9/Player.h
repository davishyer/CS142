#include <iostream>
#include <string>
#include <sstream>

using namespace std;

class Player
{
	private:
		string name;
		int wins;
		int losses;
		int drawes;

	public:
		//To create player object
		Player(string name_in, int wins_in, int losses_in, int drawes_in);
		virtual ~Player();

		//Increase wins
		void increaseWins();

		//Increase losses
		void increaseLosses();

		//Increase drawes
		void increaseDrawes();

		//Displays all information on player
		string toString();

		//Gets name of player
		string getName();

		//Gets players win record
		double getWinRecord();

		//Generates random number for fight
		int getRPSThrow();
};