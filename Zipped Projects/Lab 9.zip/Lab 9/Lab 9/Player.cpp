#include "Player.h"

using namespace std;

Player::Player(string name_in, int wins_in, int losses_in, int drawes_in)
{
	name = name_in;
	wins = wins_in;
	losses = losses_in;
	drawes = drawes_in;
}
Player::~Player(){}

string Player::toString()
{
	stringstream ss;
	ss << "Name: " << name << "   Wins: " << wins << "   Losses: " << losses << "   Drawes: " << drawes << "   ";
	return ss.str();
}

void Player::increaseWins()
{
	wins += 1;
}

void Player::increaseLosses()
{
	losses +=1;
}

void Player::increaseDrawes()
{
	drawes +=1;
}

double Player::getWinRecord()
{
	double record;
	if((wins + losses + drawes) == 0)
	{
		record = 0;
	}
	else
	{
		record = ((double)wins / (double)(wins + losses + drawes)) * 100;
	}
	return record;
}

string Player::getName()
{
	return name;
}

int Player::getRPSThrow()
{
	int i = (rand()) % 3;
	return i;
}
