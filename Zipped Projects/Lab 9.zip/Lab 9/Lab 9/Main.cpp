#include <iostream>
#include <string>
#include <vector>
#include "Player.h"
#include <time.h>

using namespace std;

int options(int& choice, int& random)
{
	cout << "1. Show all players" << endl;
	cout << "2. Add a player" << endl;
	cout << "3. Add to Line-Up" << endl;
	cout << "4. Show Line-Up" << endl;
	cout << "5. FIGHT!!" << endl;
	cout << "6. Quit Program\n\n";
	cout << "Enter your choice: ";
	cin >> choice;

	while(choice < 1 || choice > 6)
	{
		cout << "\n\nInvalid Entry\n\n";
		cout << "1. Show all players" << endl;
		cout << "2. Add a player" << endl;
		cout << "3. Add to Line-Up" << endl;
		cout << "4. Show Line-Up" << endl;
		cout << "5. FIGHT!!" << endl;
		cout << "6. Quit Program\n\n";
		cout << "Enter your choice: ";
		cin >> choice;
	}
	return choice;
}


int main()
{
	srand(time(0));
	int choice;
	int random;
	int wins = 0;
	int losses = 0;
	int drawes = 0;
	string name;
	vector <Player*> all;
	vector <Player*> line_up;
	options(choice, random);

	while(choice != 6)
	{
//Showing all players
		if(choice == 1)
		{
			if(all.empty())
			{
				cout << "\n\nThere are no players in the system\n\n" << endl;
			}

			else
			{
				for(int i = 0; i < all.size(); i++)
				{
					cout << all[i]->toString() << all[i]->getWinRecord() << "%" << endl;
				}
			}

			options(choice, random);
		}

//Adding a player
		else if(choice == 2)
		{
			bool found = false;
			cout << "\n\nEnter the name for the player you wish to add: ";
			cin >> name;
			for(int i = 0; i < all.size(); i++)
			{
				if(name == all[i]->getName())
				{
					cout << "\n\nThere is already a player with that name\n\n" << endl;
					found = true;
				}
			}
			if(found == false)
			{
				Player * p = new Player(name, 0, 0, 0);
				all.push_back(p);
				cout << "\n\n" << name << " was added\n\n";
			}

			options(choice, random);
		}

//Adding a player to the Line-Up
		else if(choice == 3)
		{
			cout << "\n\nEnter the name of the player you wish to add to the Line-Up: ";
			string add_name;
			cin >> add_name;
			bool found = false;
			int j;
			for(int i = 0; i < all.size(); i++)
			{
				if(add_name == all[i]->getName())
				{
					found = true;
					j = i;
				}
			}

			if(found == true)
			{
				line_up.push_back(all[j]);
				cout << "\n\n" << add_name << " was added to the Line-Up\n\n";
			}

			else
			{
				cout << "\n\n" << add_name << " could not be found\n\n";
			}

			options(choice, random);
		}

//Displaying the Line-Up
		else if(choice == 4)
		{
			if(line_up.empty())
			{
				cout << "\n\nThere are no fighters in the Line-Up\n\n";
			}

			else
			{
				for(int i = 0; i < line_up.size(); i++)
				{
					cout << line_up[i]->toString() << line_up[i]->getWinRecord() << "%" << endl;
				}
			}

			options(choice, random);
		}

//Running the fight
		else
		{
//0 = Rock; 1 = Paper; 2 = Scissors
			if(line_up.size() < 2)
			{
				cout << "\n\nThere are not enough fighters in the Line-Up\n\n";
			}

			else if(line_up[0]->getName() == line_up[1]->getName())
			{
				cout << line_up[0]->getName() << " vs " << line_up[1]->getName() << endl;
				cout << "\nThe fight is a draw\n\n";
				line_up[0]->increaseDrawes();
				line_up.erase(line_up.begin());
				line_up.erase(line_up.begin());
			}

			else
			{
				cout << line_up[0]->getName() << " vs " << line_up[1]->getName() << endl;
				int one = line_up[0]->getRPSThrow();
				int two = line_up[1]->getRPSThrow();

//What fighter one throws
				if(one == 0)
				{
					cout << line_up[0]->getName() << " threw rock" << endl;
				}

				else if(one == 1)
				{
					cout << line_up[0]->getName() << " threw paper" << endl;
				}

				else if(one == 2)
				{
					cout << line_up[0]->getName() << " threw scissors" << endl;
				}

//What fighter two throws
				if(two == 0)
				{
					cout << line_up[1]->getName() << " threw rock" << endl;
				}

				else if(two == 1)
				{
					cout << line_up[1]->getName() << " threw paper" << endl;
				}

				else if(two == 2)
				{
					cout << line_up[1]->getName() << " threw scissors" << endl;
				}

//Declaring winner
				if(one == two)
				{
					cout << "\n\nThe fight is a draw\n\n" << endl;
					line_up[0]->increaseDrawes();
					line_up[1]->increaseDrawes();
				}

				else if((one == 0 && two == 1) || (one == 1 && two == 2) || (one == 2 && two == 0))
				{
					cout << line_up[1]->getName() << " wins the fight\n\n";
					line_up[0]->increaseLosses();
					line_up[1]->increaseWins();
				}

				else if ((one == 0 && two == 2) || (one == 1 && two == 0) || (one == 2 && two == 1))
				{
					cout << line_up[0]->getName() << " wins the fight\n\n";
					line_up[0]->increaseWins();
					line_up[1]->increaseLosses();
				}

				line_up.erase(line_up.begin());
				line_up.erase(line_up.begin());
			}

			options(choice, random);
		}
	}

	cout << "\n\nGood Bye\n\n";

	system("pause");
	return 0;
}